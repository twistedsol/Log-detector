# Realone | Real Universe

My personal site: cloud security tracking, labs, and how to reach me. A single `index.html` with no build step, in English and French, with a dark and light theme.

## Run it locally

Open `index.html` in a browser.

## Publish it free with GitHub Pages

1. Push this repo to GitHub.
2. Go to **Settings > Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, then branch `main` and folder `/ (root)`.
4. After a minute the site is live at `https://YOUR-USERNAME.github.io/realone-site/`.

Once it's live, add `og:url` and `og:image` to the `<head>` (see the TODO comment in `index.html`).

## Labs

- [Log detector](https://github.com/YOUR-USERNAME/log-detector): a Python script that flags suspicious activity in cloud audit logs.
